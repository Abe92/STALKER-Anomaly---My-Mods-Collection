General Fire Mode Switcher Sound

Full credit goes to the following people :
HarukaSai
Ishmaeel
TheMrDemonized
TheVoidPancake ( not really, just for the idea and shit )

You are not allowed to include this addon, in any kind of Modpack, or upload it, without the persmission of the AUTHORS above. 

This addon is now based on AMCM.
Big Thanks to RavenAscendant, Tronex, Blackgrowl, Igigog, Diphenhydramine-HCl for making AMCM.

Huge thanks to all the people who hepled this addon moving forward and get better. Without them, this "project" will be just a lame ass trying from me.

Cheers